This UFO files where converted using FL5 and UFO Central Version 2.1b
https://github.com/typesupply/fontlab-scripts

Kerning was converted font FL style to Metrics Machine style using KERN Exchange FL/MM
https://github.com/typedev/MMK_FL_kerning_exchange